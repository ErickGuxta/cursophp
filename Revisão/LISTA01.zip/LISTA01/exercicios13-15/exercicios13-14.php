<?php
//exercicio 13 

function escreva($texto) {
    echo $texto;
}

escreva("Qualquer coisa, sei la"); 

// exercicio 14 
function soma($x, $y) {
    return $x + $y;
}

$resultado = soma(50000001, 3); 
echo $resultado;
